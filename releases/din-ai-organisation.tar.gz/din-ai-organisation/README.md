# Din AI-organisation

En kurateret pakke på **76 Agent Skills** til Claude, bygget til kurset "Claude Desktop 0-100". Du bygger din egen AI-organisation efter et klassisk dansk organisationsdiagram: hver afdeling er et hold AI-medarbejdere, og hver skill er én afgrænset, tilbagevendende opgave, som er valideret mod virkelige danske jobfunktioner i en SMV.

Pakken installeres samlet. Afdelingerne er bygget til at hænge sammen: de læser de samme hub-filer og afleverer artefakter videre til hinanden, så en halv installation efterlader skills, der peger på noget, der ikke findes. Du installerer én gang, og organisationen står hel.

## Organisationsdiagrammet

```
                              DIREKTIONEN
                  01 Direktionen - beslutninger & kontrakter (8)
                       02 Strategiudvikling (5)
                                  |
          +-----------------------+-----------------------+
    STAB: Viden & Data      STAB: Programledelse          |
    03 (6) "hjernen"        04 (6) "styringsrygraden"     |
          |                                               |
   +--------------+-------------+------------+-------------+--------------+---------------+
Sekretariatet   Salg &      Marketing    Økonomi        HR      IT & Udvikling  Produktudvikling
  05 (7)     Kundeservice    07 (10)       08 (5)      09 (7)      10 (11)          11 (6)
                06 (5)
```

Kernen er **03 Viden & Data** (den ejer virksomhedens hub-filer) og **01 Direktionen**. Alt andet bygger ovenpå.

## Afdelinger og skill-indeks

### 01 - Direktionen: beslutninger & kontrakter

| Skill | Formål |
|-------|--------|
| `ide-stresstest` | Presser en "skal jeg...?"-beslutning med forcing questions og slutter med én klar anbefaling og næste skridt. |
| `problemknuser` | Fører et rodet problem gennem 7 trin til en eksekveret beslutning: problemformulering, spørgsmålstræ, hypoteser med dødstest, syntese, vendepunkter og første handling inden 5 hverdage. |
| `second-opinion` | Kritisk gennemgang af egne udkast før afsendelse - send / send ikke / send efter rettelser, med citat. |
| `kontrakt-tjek` | Gennemgår modpartens kontrakter før underskrift, flager risici med klausulcitat og siger hvornår advokaten skal ind. |
| `beslutningsgrundlag` | Bygger et skriftligt, kildebelagt beslutningsgrundlag eller business case til store beslutninger. |
| `bestyrelsespakke` | Udkast til bestyrelsesmateriale, bankpræsentation eller ledelsesrapport ud fra virksomhedens egne tal. |
| `forhandlings-forberedelse` | Forbereder en konkret forhandling med BATNA, smertegrænse, aftalezone og indrømmelsesplan i ét forhandlingsark. |
| `kvalitetsloop` | Kører enhver leverance gennem fem trin - succeskriterier, udkast, kritikerpanel, revision, verifikation - før den forlader huset. Leverér aldrig første udkast. |

### 02 - Strategiudvikling

| Skill | Formål |
|-------|--------|
| `strategidag-forberedelse` | Forbereder og refererer årets strategidag: dagsorden, situationsbillede og 3-5 skarpe strategiske spørgsmål. |
| `etsides-strategiplan` | Kondenserer strategien til én læsbar side plus en medarbejderversion i klart sprog. |
| `konkurrent-radar` | Vedligeholder et stående konkurrentkort og skriver kvartalsvis delta-rapport med "hvad betyder det for os". |
| `kvartals-nedbrydning` | Nedbryder strategien til 3-5 kvartalsmål med navngivne ejere og "færdig når"-kriterier. |
| `strategi-tjek` | Kvartalsvis grøn/gul/rød-opfølgning på kvartalsmålene - fungerer også som bestyrelsesside. |

### 03 - Stab: Viden & Data (kerne)

| Skill | Formål |
|-------|--------|
| `virksomhedsprofil` | Opretter og vedligeholder `virksomhedsprofil.md` - nav-filen med stamdata, som alle andre skills læser først. |
| `videnfil-interview` | Interviewer brugeren og destillerer tavs viden til en videnfil på maks. 10 linjer. |
| `natportner` | Rydder op i brain-mappens inbox, arkiverer noter i de rigtige videnfiler og skriver en natterapport. |
| `brain-tjek` | Dokumentreview af brain-mappen: finder forældet, modstridende, dubleret og kildeløs viden. |
| `gdpr-fortegnelse` | Udkaster og vedligeholder artikel 30-fortegnelse, sletteliste og databehandleroversigt via interview. |
| `vidensarkitektur` | Bestemmer hvor ny viden hører hjemme, holder én kanonisk plads pr. fakta og skriver atomiske, forbundne noter i hjernens lagdelte hierarki. |

### 04 - Stab: Programledelse (PMO)

| Skill | Formål |
|-------|--------|
| `projekt-kickoff` | Omsætter en go-beslutning til et 1-2 siders projektkommissorium plus en milepælsplan. |
| `portefolje-status` | Samler status fra alle projekter til én trafiklys-porteføljerapport til ledelsen. |
| `risiko-issue-log` | Opretter og ajourfører projektets risikolog (3x3), issue-liste og fælles beslutningslog. |
| `projekt-prioritering` | Prioriteringsoplæg for hele porteføljen: fortsæt / pausér / stop målt mod reel kapacitet. |
| `projekt-lukning` | Lukker projekter ordentligt: afslutningstjekliste, evaluering mod succeskriterier og læringer. |
| `program-styring` | Nedbryder ét stort, tværgående initiativ i arbejdsstrømme, mapper hver strøm til afdeling og skill, og styrer overleveringerne mod ét fælles mål. |

### 05 - Sekretariatet

| Skill | Formål |
|-------|--------|
| `mail-i-min-stil` | Skriver mailudkast i ejerens egen tone på hele svartypologien - altid som kladde. |
| `indbakke-triage` | Prioriteret morgenoverblik over indbakken (Handl nu / Lav udkast / Kan vente / Til orientering). |
| `referat` | Forvandler mødenoter eller transskript til professionelt referat med beslutninger og aktioner. |
| `moedeforberedelse` | Étsides mødebriefing plus dagsordenudkast, med frisk dansk CVR-research på eksterne parter. |
| `ugestatus` | Ugens statusrapport i firefelts-format med trafiklys - kunde- eller intern teamversion. |
| `opfoelgningsliste` | Samler alle åbne aktioner til én liste (hvem/hvad/deadline/kilde) og skriver påmindelses-udkast. |
| `journalisering` | Journaliserer dokumenter efter fast navnestandard og mappetaksonomi - plan før én fil røres. |

### 06 - Salg & Kundeservice

| Skill | Formål |
|-------|--------|
| `tilbud` | Skriver bindende danske tilbud efter kort interview - acceptfrist, forbehold, moms og følgemail. |
| `kundeemner` | Researcher og scorer B2B-kundeemner 1-10 mod idealkundeprofilen, med kilde og samtaleåbner. |
| `pipeline-gennemgang` | Kører det ugentlige pipelinemøde, flager sager i stå og bygger et realistisk interval-forecast. |
| `kundesvar` | Svarudkast på svære kundehenvendelser (klager, reklamationer, afslag) med styr på købeloven. |
| `kundegennemgang` | Forbereder statusmøde med eksisterende kunde: mersalg (whitespace), churn-signaler og genforhandling. |

### 07 - Marketing & Kommunikation

| Skill | Formål |
|-------|--------|
| `toneprofil` | Udleder virksomhedens tone og skriver hub-filen `voice-profil.md`, som alle skrivende skills læser. |
| `linkedin-opslag` | Skriver LinkedIn-opslag ud fra noget konkret der er sket - én pointe og 2-3 hook-varianter. |
| `nyhedsbrev` | Skriver nyhedsbreve til permission-listen med emnelinjeforslag og én klar CTA - altid som kladde. |
| `marketing-sparring` | Prioriterer marketingtiltag efter effekt/indsats og bygger eller reviderer marketingårshjulet. |
| `content-kalender` | Bygger en månedlig content-kalender med genbrugskaskade på tværs af kanaler. |
| `kundecase` | Skaber dokumenterede kundecases med interviewguide, citatliste og indbygget samtykketrin. |
| `marketing-rapport` | Månedlig marketingrapport ud fra egne tal (GA4, Meta, LinkedIn) med indsigter og anbefalinger. |
| `pressemeddelelse` | Skriver pressemeddelelse med reel nyhedsvinkel plus pitch-mail og forslag til relevante medier. |
| `menneskeliggoer` | Fjerner AI-præget fra en tekst: skærer floskler, oppustet vigtighed, reklamesprog og fyld væk og giver teksten stemme igen. |
| `dansk-korrektur` | Korrekturlæser dansk tekst mod Retskrivningsordbogen 5 og rapporterer rettelser som før → efter med paragrafhenvisning. |

### 08 - Økonomi

| Skill | Formål |
|-------|--------|
| `bilagsrydning` | Rydder regnskabsbilag før moms: aflæser, omdøber til standard, sorterer og bygger revisor-CSV. |
| `rykker-runde` | Bygger debitoroverblik og lovmedholdelige rykkerkladder efter renteloven - altid som kladder. |
| `likviditetsoverblik` | Bygger et 13-ugers likviditetsoverblik med dansk skattekalender og bufferadvarsler. |
| `budgetopfoelgning` | Sammenholder faktiske tal med budgettet og skriver én-sides afvigelsesrapport med handlingsforslag. |
| `priskalkulation` | Gennemsigtige priskalkulationer: timepris, kostpris-plus, dækningsbidrag, break-even og følsomhed. |

### 09 - HR (People & Culture)

| Skill | Formål |
|-------|--------|
| `procedure-skriver` | Interviewer kronologisk og skriver en opgave som SOP, klar til uddelegering til medarbejder eller AI. |
| `skill-opskrift` | Pakker en tilbagevendende opgave som en færdig Claude-skill og afslutter med prøvetid-tests. |
| `rutine-bygger` | Sætter tilbagevendende rutiner op for AI-medarbejderne med trigger, input, bevis-artefakt og log. |
| `rekruttering` | Dansk rekrutteringsforløb fra kravprofil til afslag - alt tjekket mod forskelsbehandlingsloven. |
| `onboarding-offboarding` | Daterede onboardingplaner (preboarding + 30-60-90) og offboarding-tjeklister. |
| `mus-forberedelse` | Forbereder MUS- og 1:1-samtaler og skriver bagefter referat med udviklingsplan. |
| `personalepolitik` | Skriver og reviderer personalepolitikker og -håndbog med flag hvor dansk lovgivning sætter rammer. |

### 10 - IT & Udvikling

| Skill | Formål |
|-------|--------|
| `designretning` | Fastlægger ÉN sammenhængende designretning og skriver hub-filen `designprofil.md`. |
| `designvarianter` | Genererer 2-3 navngivne designvarianter af samme flade inden for den godkendte designprofil. |
| `designbygger` | Laver selve det færdige, production-grade design som kørende HTML man kan se og deploye. Go-do frem for handoff-brief. |
| `grafiker` | Producerer færdige visuelle aktiver: SVG-illustrationer, ikonsæt, diagrammer og infografik i designprofilens sprog, plus billedprompter til foto-generatorer. |
| `byggebrief` | Skriver en komplet dansk kravspecifikation (`byggebrief.md`) via interview - nul pladsholdere. |
| `plan-tjek` | Ingeniørchef-review af byggeplan eller leverandørforslag før byg: GO / GO-med-ændringer / STOP. |
| `fejldetektiv` | Systematisk fejlfinding for ikke-udviklere plus professionel fejlrapport til leverandøren. |
| `klar-tjek` | Beviskrav-baseret UAT mod `byggebrief.md` med kategoriseret mangelliste før godkendelse og betaling. |
| `tilbudssammenligning` | Sammenligner leverandørtilbud mod byggebriefen og flager danske røde flag (kodeejerskab, exit m.m.). |
| `adgangsstyring` | Vedligeholder `systemoversigt.md` og producerer on-/offboarding-tjeklister og licens-audit. |
| `sikkerhedstjek` | Vurderer phishing-mails og kører kvartalsvist sikkerheds-basistjek plus hændelsesrespons. |

### 11 - Produktudvikling

| Skill | Formål |
|-------|--------|
| `kundeinterview` | Forbereder discovery-interviews efter mor-test-princippet (fortid og adfærd, aldrig pitch) og destillerer dem bagefter til JTBD-referater og mønstre. |
| `antagelses-tjek` | Kortlægger idéens risikable antagelser i otte kategorier og designer det billigste adfærds-eksperiment for de 1-3 farligste - succesgrænse sat før testen. |
| `vaerditilbud` | Formulerer et flosklefrit værditilbud for én ydelse til ét segment efter den seksdelte JTBD-skabelon - klar til salg og marketing. |
| `produkt-etside` | Samler forretningshypotesen for én ny ydelse på én side, hver rubrik markeret [VIDEN] eller [ANTAGELSE], versioneret pr. eksperiment. |
| `lanceringsplan` | Lægger lanceringen: brohoved-segment, budskab med belæg, max 3 kanaler og 90-dages tidslinje med succeskriterier sat på forhånd. |
| `nordstjerne-maal` | Vælger én kundecentreret nordstjernemetrik plus 3-5 input-metrikker - og forklarer hvorfor omsætning aldrig er nordstjernen. |

Afdelingens metodegrundlag er kurateret fra [pm-skills](https://github.com/phuryn/pm-skills) af Paweł Huryn (MIT-licens) og klassikerne bag: Fitzpatrick ("The Mom Test"), Torres ("Continuous Discovery Habits"), Savoia ("The Right It"), Maurya (Lean Canvas) og Olsen ("The Lean Product Playbook") - oversat, omskrevet til opskriftsformatet og tilpasset danske SMV'er frem for tech-produktchefer.

## Kom i gang - følg rækkefølgen

Fem trin, i DENNE rækkefølge - ca. 45-60 minutter i alt. Så hænger alt sammen fra dag ét:

| # | Trin | Tid | Hvad det er |
|---|------|-----|-------------|
| 1 | Vælg hjernens mappe | ca. 1 min | du vælger mappen |
| 2 | Byg din company brain | ca. 20-30 min | samtale med Claude, medbring 3-5 dokumenter |
| 3 | Installér skills-pakken | ca. 2 min | én kommando |
| 4 | Udfyld hub-filerne | ca. 15-25 min | tre skills, én ad gangen |
| 5 | Sundhedstjek | ca. 1 min | `install.sh status` |

`install.sh plan` skriver den samme oversigt i terminalen (og i Claude) uden at installere noget.


1. **Vælg hjernens mappe.** En synlig mappe, du selv har valgt, fx `~/Documents/company-brain`. Aldrig inde i appens data-mappe (Bibliotek/Application Support).
2. **Byg hjernen.** Paste `company-brain-prompt.txt` ind i Claude (Cowork/Desktop), peget på mappen fra trin 1. Prompten interviewer dig og bygger struktur + CLAUDE.md.
3. **Installér skills-pakken.** Claude Code: `curl -fsSL https://skills.thomascilius.dk/install.sh | bash` - og når installeren spørger, hvor hjernen ligger, svarer du med mappen fra trin 1. Ingen GitHub-konto, intet login, ingen git. Kun Claude Desktop: upload skills som zip i stedet (se nedenfor).
4. **Udfyld hub-filerne.** Kør skillene `virksomhedsprofil`, `toneprofil` og `designretning` - så kender alle 76 skills din virksomhed, tone og visuelle retning.
5. **Tjek det hele:** `~/.claude/din-ai-org/install.sh status` - sundhedstjekket skal vise hjernen koblet og hub-filerne på plads.

(Kom du til at bytte om på 2 og 3? Ingen skade sket: `install.sh brain <sti>` kobler hjernen bagefter. Men følg rækkefølgen, så slipper du for at tænke over det.)

**Sådan hænger delene sammen:**

```
install.sh ──► ~/.claude/skills (76 skills, managed)
     │    ──► settings.json (7 hooks, merge-sikkert - rører aldrig dine egne)
     │    ──► config.json { brainPath }  ◄── ./install.sh brain <sti>
     ▼
company-brain-prompt.txt ──► bygger hjernen + genererer CLAUDE.md (driftsregler)
     ▼
hub-filer i hjernens identity/: virksomhedsprofil.md · voice-profil.md · designprofil.md
     ▲
alle 76 skills læser dem ("Find og læs virksomhedsprofil.md ... (altid)")
     ▲
brain-inject-hooken indlæser 00-index.md ambient i hver Claude Code-session
```

Hjernen er sandheden, skills er medarbejderne, hub-filerne er bindeleddet, og hooks gør det ambient. `CLAUDE.md` (genereret af prompten) styrer adfærden i hjernemappen; `settings.json` (skrevet af installeren) styrer hooks globalt. I Claude Desktop/Cowork dækker CLAUDE.md-reglerne alene; i Claude Code sørger hooks for, at hjernen er til stede i alle sessioner.

## Installationsmodel

Én kommando, hele organisationen. Du vælger ikke afdelinger til og fra, for kæderne går på tværs: `konkurrent-radar` (02) fodrer strategidagen, `tilbud` (06) køres gennem `kvalitetsloop` (01), og alt skrevet henter tonen fra `voice-profil.md`, som `toneprofil` (07) ejer. Tages en afdeling ud, knækker kæderne stille.

**Kernen er 03 Viden & Data.** Den ejer hub-filerne, som resten af huset læser. Derfor er første opgave efter install altid at køre `virksomhedsprofil` - uden den gætter organisationen om, hvem du er.

### Installer (anbefalet, Claude Code)

Den reneste vej: en installer, der lægger skills på plads, husker præcis hvad den selv har lagt, og aldrig rører dine egne skills.

```bash
curl -fsSL https://skills.thomascilius.dk/install.sh -o din-ai-assistent.sh
bash din-ai-assistent.sh plan          # de fem trin med cirka tidsforbrug (installerer intet)
bash din-ai-assistent.sh install       # installer hele pakken
bash din-ai-assistent.sh brain <sti>   # kobl din company-brain (ambient genkaldelse)

# installeren lægger sig selv ved siden af pakken - derfra er alt ét kald væk:
~/.claude/din-ai-org/install.sh status      # sundhedstjek: hooks, Node, hjerne, hub-filer
~/.claude/din-ai-org/install.sh update      # hent nyeste + geninstaller (afstemmer alt)
~/.claude/din-ai-org/install.sh uninstall   # fjern KUN det, installeren lagde
```

- **Ingen konto, intet login, ingen git.** Ligger pakken ikke ved siden af scriptet, henter installeren den som ét arkiv (`releases/din-ai-organisation.tar.gz`) over almindelig https fra `skills.thomascilius.dk`. Derfor nævner prompterne heller ikke GitHub: peger man Claude på en GitHub-URL, griber den efter git eller GitHub-connectoren, og så står kursisten med et login-spørgsmål midt i en installation, der ikke kræver konto.
- **Plan før handling.** `install.sh plan` viser de fem trin med tidsforbrug. `install` viser samme plan først og markerer, at trin 3 kører nu.

- **Én pakke, ingen valg.** Hele organisationen installeres samlet. Afdelingerne henter kontekst fra de samme hub-filer og afleverer artefakter til hinanden, så en halv installation giver skills, der peger på noget, der ikke er der.
- **Idempotent opgradering.** `~/.claude/din-ai-org/install.sh update` henter nyeste version (arkivet fra sitet, eller `git pull` hvis du kører fra en klon) og **afstemmer alt**: nye skills kommer ind, udgåede fjernes, din brain-sti bevares, og intet af dit eget røres.
- **Install-state.** Alt noteres som `managed` i `~/.claude/din-ai-org/install-state.json`. Din memory, dine regler og dine egne skills står urørt.
- **Ren afinstallation.** `uninstall` fjerner kun det, installeren lagde.
- **Hooks-lag (levende hjerne).** Installeren wirer merge-sikkert seks hooks ind i `settings.json`: **brain-inject** (ambient genkaldelse), **kontinuitet** (session-save/load, "hvor vi slap"), **notify**, **connector-vagt** (`mcp-health`, opdager tabt login på Notion, Gmail, Shopify m.m.) og **brain-guard** (beskytter hjernens kernefiler). `uninstall` fjerner kun vores, aldrig dine andre hooks. Kræver Node. **Kobl hjernen med `./install.sh brain <sti>`** (installeren spørger også selv ved install) - uden koblingen er den ambiente genkaldelse stille slukket. `./install.sh status` viser, om koblingen står rigtigt.

> **Opgraderer du fra v1?** Kør `~/.claude/din-ai-org/install.sh update` (eller hent installeren igen med kommandoen ovenfor). Version 2.0.0 fjerner det gamle udvikler-lag helt - installeren rydder selv de skills, agenter, commands og rules op, som v1 lagde på din maskine. Dine egne filer røres ikke.
>
> **Vil du beholde udviklerlaget?** Byggede du oven på v1's dev-lag - agenterne, slash-kommandoerne eller `rules/din-ai-org/` - så kør `install.sh update --behold-udviklerlaget`. Så opgraderes de 76 skills, mens laget bliver stående. Valget huskes i install-state, så senere `update` også bevarer det; `--drop-udviklerlaget` rydder op og glemmer valget igen. Flaget er fra som standard: en ny kursist skal ikke slæbe rundt på et lag, kurset ikke bruger.

### Claude Desktop

Skills uploades pr. stk. som en zip-fil under **Settings > Capabilities > Skills**. Zip den enkelte skill-mappe (mappen med `SKILL.md` og dens `references/`), og upload zippen. Gentag for hver skill i de afdelinger, du har valgt.

### Claude Code

**Nemmest - lad Claude Code installere.** Indsæt denne i Claude Code. Den viser dig planen først, spørger om du er klar, og installerer derefter:

```
Installer Din AI Assistent - ThomasCilius.dk for mig. Alt hentes over almindelig https fra skills.thomascilius.dk: brug IKKE git, gh eller GitHub-connectoren, og bed mig aldrig om at logge ind nogen steder. 1) Hent installeren: curl -fsSL https://skills.thomascilius.dk/install.sh -o ~/Downloads/din-ai-assistent.sh 2) Vis mig planen FØRST: kør 'bash ~/Downloads/din-ai-assistent.sh plan', gengiv de fem trin med cirka tidsforbrug, og spørg om jeg er klar. 3) Når jeg siger ja: 'bash ~/Downloads/din-ai-assistent.sh install'. 4) Spørg derefter, hvor min company-brain ligger (eller skal ligge), og kør 'bash ~/Downloads/din-ai-assistent.sh brain <sti>' - uden den kobling indlæses hjernen aldrig ambient. 5) Vis mig til sidst '~/.claude/din-ai-org/install.sh status' og forklar hver linje, der ikke er [OK].
```

**Opdater senere.** Indsæt denne, så henter den nyeste og afstemmer alt:

```
Opdater min Din AI Assistent - ThomasCilius.dk: kør '~/.claude/din-ai-org/install.sh update'. Den henter nyeste version over almindelig https fra skills.thomascilius.dk - ingen git, ingen GitHub-konto, intet login, og den rører ikke mine egne filer. Vis mig bagefter '~/.claude/din-ai-org/install.sh status'.
```

**Eller i terminalen - én linje:**

```
curl -fsSL https://skills.thomascilius.dk/install.sh | bash
```

Begge veje giver en **managed, opdaterbar** installation (global i `~/.claude/`), i modsætning til at kopiere skill-mapper løst ind. Derefter henter `~/.claude/din-ai-org/install.sh update` altid nyeste og afstemmer alt.

Hver skill-mappe (fx `virksomhedsprofil/`) lægges som en undermappe med sin `SKILL.md` og `references/` intakt.

### Download pr. afdeling (zip)

Vil du hente en hel afdeling på én gang, ligger færdige zips i [`releases/`](releases) - eller brug **⬇ Zip**-knappen ved hver afdeling på [skills.thomascilius.dk](https://skills.thomascilius.dk/). Hver zip har afdelingens skill-mapper i roden:

- **Claude Code:** pak ud direkte i `~/.claude/skills/` (fx `unzip 03-viden-og-data.zip -d ~/.claude/skills/`).
- **Claude Desktop:** pak ud, og upload de enkelte skill-mapper hver for sig (Desktop tager én skill ad gangen).

Zips regenereres med `scripts/make-zips.sh` efter ændringer i skills.

## Konventioner

Alle 76 skills følger den samme opskrift, så de opfører sig ens uanset afdeling.

- **Danske skill-navne** - "noget du selv ville sige højt". Navnefeltet tillader kun a-z, tal og bindestreg, så æ/ø/å translittereres til ae/oe/aa: `moedeforberedelse`, `opfoelgningsliste`, `budgetopfoelgning`.
- **Tosprogede triggere** - hver `description` indeholder ordrette triggersætninger på både dansk og engelsk ("skriv et tilbud" / "write a proposal"), skrevet pushy fordi Claude har tendens til at undertrigge.
- **Aldrig-regler** er en fast del af formatet: skills leverer altid en kladde; sender, sletter og bogfører aldrig selv; laver en plan før den rører filer; citerer kilden; og AI anbefaler - mennesket beslutter. Følsomt arbejde har navngivne eskalationstriggere (advokat, revisor, jurist).
- **Hub-filer (hub-and-spoke).** Konteksten gives ÉN gang og genbruges af alle skills:
  - `virksomhedsprofil.md` - ejes af `virksomhedsprofil` (03). Alle skills læser den først.
  - `voice-profil.md` - ejes af `toneprofil` (07). Alle skrivende skills læser den.
  - `designprofil.md` - ejes af `designretning` (10). Alle visuelle leverancer læser den.
- **Artefakt-kæder.** Hver skill efterlader et navngivet artefakt, som den næste skill i kæden læser:
  - **Strategi-årshjulet:** `konkurrent-radar` -> `strategidag-forberedelse` -> `etsides-strategiplan` -> `kvartals-nedbrydning` -> `strategi-tjek` -> (næste års strategidag)
  - **Byggerejsen:** `ide-stresstest` -> `designretning` -> `designvarianter` -> `byggebrief` -> `plan-tjek` -> byg -> `fejldetektiv` -> `klar-tjek` -> `procedure-skriver`
  - **Projektlivscyklus:** `ide-stresstest` / `beslutningsgrundlag` -> `projekt-kickoff` -> `risiko-issue-log` -> `portefolje-status` -> `projekt-prioritering` -> `projekt-lukning`
  - **Salgsflow:** `kundeemner` -> `moedeforberedelse` (salgstilstand) -> `tilbud` -> `pipeline-gennemgang` -> `kundegennemgang`
  - **Skrivekæden:** `toneprofil` -> den skrivende skill (`linkedin-opslag` / `nyhedsbrev` / `kundecase` / `pressemeddelelse` / `mail-i-min-stil` / `tilbud`) -> `menneskeliggoer` -> `dansk-korrektur` -> `kvalitetsloop` -> `second-opinion` ved høj indsats
  - **Produktrejsen:** `kundeinterview` -> `antagelses-tjek` -> `vaerditilbud` -> `produkt-etside` -> `lanceringsplan` -> `nordstjerne-maal` - med `ide-stresstest` som go/no-go-port undervejs og aflevering til marketing- og salgskæderne ved lancering

På tværs af kæderne er `program-styring` (04) dirigenten for store, tværgående initiativer: den nedbryder ét initiativ i arbejdsstrømme og mapper hver strøm til den skill der løser den. Den virker dual-mode - Desktop-dirigeret (mennesket åbner hver afdelingsskill i rækkefølge) eller Claude Code-subagent-dispatch (én subagent pr. strøm) - og leverer status videre til `portefolje-status` og `risiko-issue-log`.

Pakken bygger desuden ovenpå Claudes indbyggede dokumentskills (pptx, pdf, docx, xlsx) via `designprofil.md` og duplikerer dem ikke.

### Ét valgfrit download: RO5-ordformlisten

`dansk-korrektur` (07) virker ud af boksen på retskrivningsreglerne, som følger med pakken. Vil du have maskinelt verificeret stavekontrol mod alle ca. 535.000 ordformer i Retskrivningsordbogen 5, henter du datafilen (31 MB, CC0 fra Dansk Sprognævn) én gang - opskriften står i `07-marketing/dansk-korrektur/references/om-ro5-data.md`. Filen er for stor til repoet og er derfor bevidst holdt udenfor.

## Kom godt i gang

**Trin 0 - byg din company brain.** Fundamentet under det hele: en levende markdown-vidensbase på din egen maskine, som Claude selv vedligeholder. Åbn en ny Cowork-samtale med adgang til en tom mappe (fx `company-brain/`) og kopiér [`company-brain-prompt.txt`](company-brain-prompt.txt) ind - eller brug kopiér-knappen på [skills.thomascilius.dk](https://skills.thomascilius.dk/#brain). Se guiden og facilitator-noterne i [`company-brain-bootstrap.md`](company-brain-bootstrap.md). Hjernen er fundamentet, skill-pakken er medarbejderne der arbejder oven på den.

**Har du allerede en hjerne?** Findes `00-index.md` i mappen, er Trin 0 gjort. Spring bygningen over og installér skills oven på den - `virksomhedsprofil` opdaterer så bare din eksisterende `identity/virksomhedsprofil.md`, den bygger ikke en ny hjerne.

Derefter:

1. **Kør `virksomhedsprofil` først.** Den opretter (eller opdaterer) `identity/virksomhedsprofil.md` - den fælles nav-fil, alle andre skills læser før de arbejder. Har Trin 0 allerede bygget den, opdaterer skillen den bare. Uden den gætter resten af organisationen om, hvem du er.
2. **Kør derefter `toneprofil`** (07) for at skrive `voice-profil.md`, hvis du vil have skrivende skills til at ramme din stemme, og `designretning` (10) for `designprofil.md`, hvis du skal lave visuelle leverancer.
3. **Vælg dine afdelinger** ud fra din rolle, og installér dem oven på kernen.

Én gang investeret kontekst, genbrugt af hele organisationen.
